﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SearchPanelDemo.DAL;
using SearchPanelDemo.Models;
using System.Web.Helpers;
using System.Web.WebPages;

namespace SearchPanelDemo.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index(string zipfilter, string cityfilter, string statefilter, 
            string latitudefilter, string longitudefilter)
        {
            ViewBag.Title = "US Postal Codes";
            List<PostalCodeModel> viewModel = Accessor.FetchPostalCodes().ToList();

            if (!string.IsNullOrWhiteSpace(zipfilter))
                viewModel = viewModel.Where(p => p.ZipCode.StartsWith(zipfilter)).ToList();

            if (!string.IsNullOrWhiteSpace(cityfilter))
                viewModel = viewModel.Where(p => p.City.ToUpper().StartsWith(cityfilter.ToUpper())).ToList();

            if (!string.IsNullOrWhiteSpace(statefilter))
                viewModel = viewModel.Where(p => p.State.ToUpper().StartsWith(statefilter.ToUpper())).ToList();

            if (!string.IsNullOrWhiteSpace(latitudefilter))
                viewModel = viewModel.Where(p => p.Latitude.Contains(latitudefilter)).ToList();

            if (!string.IsNullOrWhiteSpace(longitudefilter))
                viewModel = viewModel.Where(p => p.Longitude.Contains(longitudefilter)).ToList();

            return View(viewModel);
        }

    }
}
