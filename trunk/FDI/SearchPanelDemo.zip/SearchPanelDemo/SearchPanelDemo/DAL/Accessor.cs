﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SearchPanelDemo.Models;

namespace SearchPanelDemo.DAL
{
    public class Accessor
    {
        public static IEnumerable<PostalCodeModel> FetchPostalCodes()
        {
            PostalCodesEntities context = new PostalCodesEntities();

            return (from a in context.ZIP_Codes
                    join b in context.States on a.State_Code equals b.State_Code
                    orderby b.State_Code ascending, a.City, a.ZIP_Code1 ascending 
                    select new PostalCodeModel
                    {
                          ZipCode = a.ZIP_Code1,
                          City = a.City,
                          State = b.State_Abbreviation,
                          Latitude = a.Latitude,
                          Longitude = a.Longitude
                    }).ToList<PostalCodeModel>();

        }
    }
}
